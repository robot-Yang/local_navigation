#include "Form_yamahack.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form_yamahack w;
    w.show();

    return a.exec();
}
